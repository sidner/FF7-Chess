#ifndef MYTEXTURECUBE_H
#define MYTEXTURECUBE_H

#include "CGFobject.h"

class myTextureCube: public CGFobject {
	public:
		void draw();
};

#endif
