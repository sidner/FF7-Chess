CGFlib headers should be placed in this folder.
If they are missing, please obtain them from the binary distributable or from source (they must match the static library in the lib folder).